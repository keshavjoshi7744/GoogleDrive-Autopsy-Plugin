# -*- coding: utf-8 -*-
"""
Google Drive Sync Artifact Parser for Autopsy
-------------------------------------------------
Keshav Joshi
MSc Cyber Security, University of York
Supervisor: Dr Angus Marshall
This Autopsy ingest module automates forensic extraction and mapping of modern
Google Drive for Desktop (DriveFS) artifacts such as DBs, logs, and config files.

Features:
- Locates and parses DriveFS SQLite databases for file listings and status.
- Extracts sync event logs and user actions from structured logs.
- Parses LocalPrefs.json, startup_trace, and parent mapping config files.
- Maps evidence to Autopsy artifacts for timeline and workflow integration.
- Written as part of MSc cybersecurity dissertation research (2025).

Usage:
- Place this script in Autopsy's python_modules directory.
- Requires sqlite-jdbc.jar in Autopsy's modules path.
"""

import os
import jarray
import re

from java.util import ArrayList
from java.io import FileOutputStream, BufferedOutputStream
from java.sql import DriverManager, SQLException
from java.lang import Class, ClassNotFoundException
from org.sleuthkit.datamodel import ReadContentInputStream, BlackboardAttribute
from org.sleuthkit.autopsy.casemodule import Case
from org.sleuthkit.autopsy.ingest import IngestModule, IngestModuleFactoryAdapter, DataSourceIngestModule
from org.sleuthkit.autopsy.ingest import IngestMessage, IngestServices
from org.sleuthkit.autopsy.coreutils import Logger
from org.sleuthkit.datamodel import TskCoreException
from java.util.logging import Level

MODULE_NAME = "Google DriveFS Parser"
VERSION = "4.0"

class GoogleDriveIngestModuleFactory(IngestModuleFactoryAdapter):
    def getModuleDisplayName(self):
        return MODULE_NAME
        
    def getModuleDescription(self):
        return "Complete DriveFS parser: databases + logs + config files (LocalPrefs.json, startup_trace.json, parent.txt)"
        
    def getModuleVersionNumber(self):
        return VERSION
        
    def isDataSourceIngestModuleFactory(self):
        return True
        
    def createDataSourceIngestModule(self, ingestOptions):
        return GoogleDriveIngestModule()

class GoogleDriveIngestModule(DataSourceIngestModule):
    
    def __init__(self):
        self.context = None
        self.logger = None
        self.jdbcLoaded = False
        
    def startUp(self, context):
        self.context = context
        self.logger = Logger.getLogger(self.__class__.__name__)
        
        # Attempt to load the SQLite JDBC driver required for parsing Google databases.
        try:
            Class.forName("org.sqlite.JDBC").newInstance()
            self.jdbcLoaded = True
            self.logger.log(Level.INFO, "[{}] JDBC SQLite driver loaded successfully".format(MODULE_NAME))
        except ClassNotFoundException as e:
            self.logger.log(Level.SEVERE, "[{}] JDBC driver error: {}".format(MODULE_NAME, str(e)))
            return IngestModule.ProcessResult.ERROR
        
        # Set up artifact types and attributes
        self._setupArtifacts()
        self.logger.log(Level.INFO, "[{}] v{} - Complete DriveFS analysis: DB + logs + config files".format(MODULE_NAME, VERSION))
        
    def _setupArtifacts(self):
        """Setup database, log, and config artifact types with comprehensive attributes"""
        try:
            skCase = Case.getCurrentCase().getSleuthkitCase()
            
            # Existing database artifact type
            try:
                self.dbArtType = skCase.addBlackboardArtifactType(
                    "TSK_GOOGLE_DRIVEFS_ITEM", "Google DriveFS Item")
            except TskCoreException:
                self.dbArtType = skCase.getArtifactType("TSK_GOOGLE_DRIVEFS_ITEM")
            
            # Existing log event artifact type
            try:
                self.logArtType = skCase.addBlackboardArtifactType(
                    "TSK_DRIVEFS_LOG_EVENT", "Google DriveFS Log Event")
            except TskCoreException:
                self.logArtType = skCase.getArtifactType("TSK_DRIVEFS_LOG_EVENT")
            
            # NEW: Config artifact type for LocalPrefs.json, startup_trace.json, parent.txt
            try:
                self.configArtType = skCase.addBlackboardArtifactType(
                    "TSK_DRIVEFS_CONFIG", "Google DriveFS Config")
                self.logger.log(Level.INFO, "[{}] Created new artifact type: Google DriveFS Config".format(MODULE_NAME))
            except TskCoreException:
                self.configArtType = skCase.getArtifactType("TSK_DRIVEFS_CONFIG")
                self.logger.log(Level.INFO, "[{}] Using existing artifact type: Google DriveFS Config".format(MODULE_NAME))
            
            self._createCustomAttributes(skCase)
            
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Artifact setup error: {}".format(MODULE_NAME, str(e)))
            
    def _createCustomAttributes(self, skCase):
        """Create attributes for database, log, and config artifacts"""
        # EXISTING: Database artifact attributes (preserved)
        self.attDrivefsId = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_ID",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "DriveFS File ID")
        self.attFilename = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_FILENAME", 
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Filename")
        self.attMimeType = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_MIME",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "MIME Type")
        self.attFileSize = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_SIZE",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.LONG, "File Size")
        self.attModifiedTime = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_MODIFIED",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.DATETIME, "Modified Time")
        self.attSyncStatus = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_SYNC_STATUS",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Sync Status")
        
        # EXISTING: Log event attributes (preserved)
        self.attLogEventTime = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_TIMESTAMP",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.DATETIME, "Event Timestamp")
        self.attLogEventType = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_EVENT_TYPE",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Event Type")
        self.attLogFileId = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_FILE_ID",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "File ID")
        self.attLogFilename = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_FILENAME",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Filename")
        self.attLogUserEmail = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_USER_EMAIL",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "User Email")
        self.attLogSourceFile = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_SOURCE_FILE",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Source File")
        self.attLogMessage = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_LOG_MESSAGE",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Event Message")
        
        # NEW: Config file attributes for comprehensive DriveFS configuration analysis
        self.attConfigType = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_CONFIG_TYPE",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Config Type")
        self.attAccountEmail = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_ACCOUNT_EMAIL",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Account Email")
        self.attMachineId = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_MACHINE_ID",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Machine ID")
        self.attProfileId = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_PROFILE_ID",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Profile ID")
        self.attStartupTime = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_STARTUP_TIME",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.DATETIME, "Startup Time")
        self.attFeatureFlags = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_FLAGS",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Feature Flags")
        self.attErrorCodes = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_ERROR_CODES",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Error Codes")
        self.attParentId = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_PARENT_ID",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Parent ID")
        self.attChildId = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_CHILD_ID",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Child ID")
        self.attConfigSourceFile = self._getOrCreateAttribute(skCase, "TSK_DRIVEFS_CONFIG_SOURCE_FILE",
            BlackboardAttribute.TSK_BLACKBOARD_ATTRIBUTE_VALUE_TYPE.STRING, "Config Source File")
            
    def _getOrCreateAttribute(self, skCase, name, valueType, displayName):
        """Get existing attribute or create new one"""
        try:
            return skCase.addArtifactAttributeType(name, valueType, displayName)
        except TskCoreException:
            return skCase.getAttributeType(name)
    
    def process(self, dataSource, progressBar):
        """Main processing: databases + logs + config files for comprehensive DriveFS analysis"""
        if not self.jdbcLoaded:
            self.logger.log(Level.SEVERE, "[{}] JDBC driver not loaded".format(MODULE_NAME))
            return IngestModule.ProcessResult.ERROR
            
        progressBar.switchToIndeterminate()
        
        # EXISTING: Process database files (preserved functionality)
        dbFiles = self._findDriveFSFiles(dataSource)
        totalDbArtifacts = self._processDatabaseFiles(dbFiles)
        
        # EXISTING: Process log files (preserved functionality)
        logFiles = self._findAllLogFiles(dataSource)
        totalLogArtifacts = self._processAllLogFiles(logFiles)
        
        # NEW: Process config files (LocalPrefs.json, startup_trace.json, parent.txt)
        configFiles = self._findConfigFiles(dataSource)
        totalConfigArtifacts = self._processConfigFiles(configFiles)
        
        # Send completion message with comprehensive forensic summary
        totalArtifacts = totalDbArtifacts + totalLogArtifacts + totalConfigArtifacts
        if totalArtifacts > 0:
            message = IngestMessage.createMessage(
                IngestMessage.MessageType.DATA,
                MODULE_NAME,
                "Complete DriveFS Analysis: {} database + {} log events + {} config items = {} total artifacts".format(
                    totalDbArtifacts, totalLogArtifacts, totalConfigArtifacts, totalArtifacts)
            )
            IngestServices.getInstance().postMessage(message)
        
        self.logger.log(Level.INFO, "[{}] Complete forensic analysis: {} DB + {} log + {} config artifacts".format(
            MODULE_NAME, totalDbArtifacts, totalLogArtifacts, totalConfigArtifacts))
        return IngestModule.ProcessResult.OK
        
    def _processDatabaseFiles(self, dbFiles):
        """EXISTING: Process database files (preserved functionality)"""
        totalProcessed = 0
        
        if not dbFiles:
            self.logger.log(Level.WARNING, "[{}] No DriveFS databases found".format(MODULE_NAME))
            return 0
            
        self.logger.log(Level.INFO, "[{}] Processing {} DriveFS database files".format(MODULE_NAME, len(dbFiles)))
        
        for dbFile in dbFiles:
            if self.context.isJobCancelled():
                break
                
            self.logger.log(Level.INFO, "[{}] Processing database: {}".format(MODULE_NAME, dbFile.getName()))
            
            tempPath = self._copyToTemp(dbFile)
            if not tempPath:
                continue
                
            try:
                items = self._parseDatabase(tempPath)
                artifactCount = self._createDatabaseArtifacts(dbFile, items)
                totalProcessed += artifactCount
                
                self.logger.log(Level.INFO, "[{}] Database analysis complete: {} artifacts from {}".format(
                    MODULE_NAME, artifactCount, dbFile.getName()))
                    
            finally:
                try:
                    os.remove(tempPath)
                except:
                    pass
        
        return totalProcessed
        
    def _processAllLogFiles(self, logFiles):
        """EXISTING: Process log files (preserved functionality)"""
        totalProcessed = 0
        
        if not logFiles:
            self.logger.log(Level.WARNING, "[{}] No DriveFS log files found".format(MODULE_NAME))
            return 0
            
        self.logger.log(Level.INFO, "[{}] Processing {} DriveFS log files".format(MODULE_NAME, len(logFiles)))
        
        for logFile in logFiles:
            if self.context.isJobCancelled():
                break
                
            self.logger.log(Level.INFO, "[{}] Processing log file: {}".format(MODULE_NAME, logFile.getUniquePath()))
            
            tempPath = self._copyToTemp(logFile)
            if not tempPath:
                continue
                
            try:
                events = self._parseLogFile(tempPath, logFile)
                artifactCount = self._createLogArtifacts(logFile, events)
                totalProcessed += artifactCount
                
                self.logger.log(Level.INFO, "[{}] Log analysis complete: {} events from {}".format(
                    MODULE_NAME, artifactCount, logFile.getName()))
                    
            finally:
                try:
                    os.remove(tempPath)
                except:
                    pass
        
        return totalProcessed
        
    def _processConfigFiles(self, configFiles):
        """NEW: Process DriveFS config files for comprehensive system analysis"""
        totalProcessed = 0
        
        if not configFiles:
            self.logger.log(Level.WARNING, "[{}] No DriveFS config files found - missing configuration evidence".format(MODULE_NAME))
            return 0
            
        self.logger.log(Level.INFO, "[{}] Processing {} DriveFS config files for system configuration analysis".format(MODULE_NAME, len(configFiles)))
        
        for configFile in configFiles:
            if self.context.isJobCancelled():
                break
                
            self.logger.log(Level.INFO, "[{}] Processing config file: {}".format(MODULE_NAME, configFile.getUniquePath()))
            
            tempPath = self._copyToTemp(configFile)
            if not tempPath:
                continue
                
            try:
                configs = self._parseConfigFile(tempPath, configFile)
                artifactCount = self._createConfigArtifacts(configFile, configs)
                totalProcessed += artifactCount
                
                self.logger.log(Level.INFO, "[{}] Config analysis complete: {} items from {}".format(
                    MODULE_NAME, artifactCount, configFile.getName()))
                    
            finally:
                try:
                    os.remove(tempPath)
                except:
                    pass
        
        return totalProcessed
        
    def _findDriveFSFiles(self, dataSource):
        """EXISTING: Find DriveFS database files (preserved)"""
        fileManager = Case.getCurrentCase().getServices().getFileManager()
        dbFiles = []
        
        dbNames = ["mirror_metadata_sqlite.db", "metadata_sqlite_db"]
        
        for dbName in dbNames:
            try:
                files = fileManager.findFiles(dataSource, dbName)
                for f in files:
                    path = f.getUniquePath().lower()
                    if "google" in path and "drivefs" in path:
                        dbFiles.append(f)
                        self.logger.log(Level.INFO, "[{}] Found DriveFS database: {}".format(MODULE_NAME, f.getUniquePath()))
            except Exception as e:
                self.logger.log(Level.WARNING, "[{}] Database search error for {}: {}".format(MODULE_NAME, dbName, str(e)))
                
        return dbFiles
        
    def _findAllLogFiles(self, dataSource):
        """EXISTING: Find DriveFS log files (preserved)"""
        fileManager = Case.getCurrentCase().getServices().getFileManager()
        logFiles = []
        
        logPatterns = ["structured_log_global", "drive_fs.txt", "startup_trace.json"]
        
        for pattern in logPatterns:
            try:
                files = fileManager.findFiles(dataSource, pattern)
                for f in files:
                    path = f.getUniquePath().lower()
                    if (("google" in path and "drivefs" in path) or 
                        pattern.lower() in f.getName().lower()):
                        logFiles.append(f)
                        self.logger.log(Level.INFO, "[{}] Found DriveFS log file: {} [Type: {}]".format(
                            MODULE_NAME, f.getUniquePath(), pattern))
            except Exception as e:
                self.logger.log(Level.WARNING, "[{}] Log file search error for {}: {}".format(
                    MODULE_NAME, pattern, str(e)))
                
        return logFiles
        
    def _findConfigFiles(self, dataSource):
        """NEW: Find DriveFS configuration files (LocalPrefs.json, startup_trace_*.json, parent_*.txt)"""
        fileManager = Case.getCurrentCase().getServices().getFileManager()
        configFiles = []
        
        # Search patterns for config files
        configPatterns = [
            "LocalPrefs.json",
            "startup_trace_*",  # Will match startup_trace_*.json
            "parent_*"  # Will match parent_*.txt
        ]
        
        for pattern in configPatterns:
            try:
                files = fileManager.findFiles(dataSource, pattern)
                for f in files:
                    path = f.getUniquePath().lower()
                    fileName = f.getName().lower()
                    
                    # Accept files in Google/DriveFS paths or files with matching patterns
                    if (("google" in path and "drivefs" in path) or 
                        "localprefs.json" in fileName or
                        "startup_trace" in fileName or
                        "parent_" in fileName):
                        configFiles.append(f)
                        self.logger.log(Level.INFO, "[{}] Found DriveFS config file: {} [Pattern: {}]".format(
                            MODULE_NAME, f.getUniquePath(), pattern))
            except Exception as e:
                self.logger.log(Level.WARNING, "[{}] Config file search error for {}: {}".format(
                    MODULE_NAME, pattern, str(e)))
        
        # Also search for files with specific extensions in DriveFS directories
        try:
            # Find JSON files in DriveFS directories
            jsonFiles = fileManager.findFiles(dataSource, "*.json")
            for f in jsonFiles:
                path = f.getUniquePath().lower()
                fileName = f.getName().lower()
                if ("google" in path and "drivefs" in path and 
                    ("localprefs" in fileName or "startup_trace" in fileName)):
                    if f not in configFiles:  # Avoid duplicates
                        configFiles.append(f)
                        self.logger.log(Level.INFO, "[{}] Found DriveFS JSON config: {}".format(
                            MODULE_NAME, f.getUniquePath()))
            
            # Find TXT files in DriveFS directories
            txtFiles = fileManager.findFiles(dataSource, "*.txt")
            for f in txtFiles:
                path = f.getUniquePath().lower()
                fileName = f.getName().lower()
                if ("google" in path and "drivefs" in path and "parent" in fileName):
                    if f not in configFiles:  # Avoid duplicates
                        configFiles.append(f)
                        self.logger.log(Level.INFO, "[{}] Found DriveFS TXT config: {}".format(
                            MODULE_NAME, f.getUniquePath()))
                        
        except Exception as e:
            self.logger.log(Level.WARNING, "[{}] Extended config search error: {}".format(MODULE_NAME, str(e)))
                
        self.logger.log(Level.INFO, "[{}] Config file discovery complete: {} total config files found".format(
            MODULE_NAME, len(configFiles)))
        return configFiles
        
    def _copyToTemp(self, abstractFile):
        """EXISTING: Copy file to temp location (preserved functionality)"""
        tempDir = Case.getCurrentCase().getTempDirectory()
        tempPath = os.path.join(tempDir, "drivefs_{}_{}.tmp".format(
            abstractFile.getId(), abstractFile.getName().replace("/", "_")))
            
        try:
            inputStream = ReadContentInputStream(abstractFile)
            outputStream = BufferedOutputStream(FileOutputStream(tempPath))
            
            buffer = jarray.zeros(8192, 'b')
            while True:
                bytesRead = inputStream.read(buffer)
                if bytesRead == -1:
                    break
                outputStream.write(buffer, 0, bytesRead)
                
            outputStream.close()
            inputStream.close()
            return tempPath
            
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Failed to copy {} to temp: {}".format(
                MODULE_NAME, abstractFile.getName(), str(e)))
            return None
            
    def _parseDatabase(self, dbPath):
        """EXISTING: Parse DriveFS database (preserved functionality)"""
        items = []
        
        try:
            conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)
            stmt = conn.createStatement()
            
            rs = stmt.executeQuery("SELECT COUNT(*) as total FROM items")
            if rs.next():
                total = rs.getInt("total")
                self.logger.log(Level.INFO, "[{}] Database contains {} total items".format(MODULE_NAME, total))
            rs.close()
            
            sql = """
            SELECT stable_id, id, local_title, mime_type, file_size, modified_date, 
                   trashed, is_folder, shared_with_me_date, is_owner
            FROM items 
            WHERE is_tombstone = 0 
            AND local_title IS NOT NULL 
            AND local_title != ''
            ORDER BY modified_date DESC 
            LIMIT 2000
            """
            
            rs = stmt.executeQuery(sql)
            
            while rs.next():
                item = {}
                item['stable_id'] = rs.getString("stable_id") or ""
                item['id'] = rs.getString("id") or ""
                item['local_title'] = rs.getString("local_title") or ""
                item['mime_type'] = rs.getString("mime_type") or ""
                item['file_size'] = rs.getLong("file_size") if rs.getLong("file_size") else 0
                item['modified_date'] = rs.getLong("modified_date") if rs.getLong("modified_date") else 0
                item['trashed'] = rs.getBoolean("trashed") if rs.getObject("trashed") else False
                items.append(item)
            
            rs.close()
            stmt.close()
            conn.close()
            
            self.logger.log(Level.INFO, "[{}] Database parsing complete: {} items extracted".format(
                MODULE_NAME, len(items)))
            
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Database parse error: {}".format(MODULE_NAME, str(e)))
            
        return items
        
    def _parseLogFile(self, logPath, sourceFile):
        """EXISTING: Parse log files (preserved functionality)"""
        fileName = sourceFile.getName().lower()
        events = []
        
        try:
            if "structured_log_global" in fileName:
                events = self._parseStructuredLogGlobal(logPath, sourceFile)
            elif "drive_fs.txt" in fileName:
                events = self._parseDriveFSText(logPath, sourceFile)
            elif "startup_trace.json" in fileName:
                events = self._parseStartupTraceJSON(logPath, sourceFile)
            else:
                events = self._parseGenericLog(logPath, sourceFile)
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Log file parsing error: {}".format(MODULE_NAME, str(e)))
            
        return events
        
    def _parseConfigFile(self, configPath, sourceFile):
        """NEW: Parse config file based on type (LocalPrefs.json, startup_trace_*.json, parent_*.txt)"""
        fileName = sourceFile.getName().lower()
        configs = []
        
        try:
            if "localprefs.json" in fileName:
                configs = self._parseLocalPrefsJSON(configPath, sourceFile)
            elif "startup_trace" in fileName and fileName.endswith(".json"):
                configs = self._parseStartupTraceConfigJSON(configPath, sourceFile)
            elif "parent" in fileName and fileName.endswith(".txt"):
                configs = self._parseParentMappingTXT(configPath, sourceFile)
            else:
                self.logger.log(Level.WARNING, "[{}] Unknown config file type: {} - attempting generic parsing".format(
                    MODULE_NAME, fileName))
                configs = self._parseGenericConfig(configPath, sourceFile)
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Config file parsing error for {}: {}".format(
                MODULE_NAME, sourceFile.getName(), str(e)))
            
        return configs
        
    def _parseLocalPrefsJSON(self, configPath, sourceFile):
        """Parse LocalPrefs.json for account and machine configuration"""
        configs = []
        
        self.logger.log(Level.INFO, "[{}] Parsing LocalPrefs.json for account and machine configuration".format(MODULE_NAME))
        
        try:
            configFile = open(configPath, 'r')
            try:
                content = configFile.read()
                
                config = self._extractLocalPrefsData(content, sourceFile.getName())
                if config:
                    configs.append(config)
                    self.logger.log(Level.INFO, "[{}] LocalPrefs config extracted: Account={}, Machine={}".format(
                        MODULE_NAME, config.get('account_email', 'N/A'), 
                        config.get('machine_id', 'N/A')))
            finally:
                configFile.close()
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] LocalPrefs.json parse error: {}".format(MODULE_NAME, str(e)))
            
        return configs
        
    def _parseStartupTraceConfigJSON(self, configPath, sourceFile):
        """Parse startup_trace_*.json for startup timing and feature flags"""
        configs = []
        
        self.logger.log(Level.INFO, "[{}] Parsing startup_trace.json for startup timing and flags".format(MODULE_NAME))
        
        try:
            configFile = open(configPath, 'r')
            try:
                content = configFile.read()
                
                config = self._extractStartupTraceData(content, sourceFile.getName())
                if config:
                    configs.append(config)
                    self.logger.log(Level.INFO, "[{}] Startup trace config extracted: Time={}, Flags={}".format(
                        MODULE_NAME, config.get('startup_time', 'N/A'), 
                        config.get('flags', 'N/A')))
            finally:
                configFile.close()
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] startup_trace.json parse error: {}".format(MODULE_NAME, str(e)))
            
        return configs
        
    def _parseParentMappingTXT(self, configPath, sourceFile):
        """Parse parent_*.txt for file ID to parent folder mappings"""
        configs = []
        linesProcessed = 0
        
        self.logger.log(Level.INFO, "[{}] Parsing parent mapping file for file ID relationships".format(MODULE_NAME))
        
        try:
            configFile = open(configPath, 'r')
            try:
                for lineNum, line in enumerate(configFile, 1):
                    linesProcessed += 1
                    line = line.strip()
                    
                    if not line or line.startswith('#'):  # Skip empty lines and comments
                        continue
                        
                    try:
                        config = self._extractParentMappingData(line, sourceFile.getName())
                        if config:
                            configs.append(config)
                            
                            # Log sample mappings for validation
                            if len(configs) <= 3:
                                self.logger.log(Level.INFO, "[{}] Sample parent mapping: Child={}, Parent={}".format(
                                    MODULE_NAME, config.get('child_id', 'N/A'), 
                                    config.get('parent_id', 'N/A')))
                    
                    except Exception as e:
                        continue  # Skip invalid lines
                        
                    # Performance limit
                    if len(configs) >= 1000:
                        break
            finally:
                configFile.close()
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] parent mapping file parse error: {}".format(MODULE_NAME, str(e)))
            
        self.logger.log(Level.INFO, "[{}] Parent mapping analysis complete: {} mappings from {} lines".format(
            MODULE_NAME, len(configs), linesProcessed))
        
        return configs
        
    def _parseGenericConfig(self, configPath, sourceFile):
        """Generic config parsing fallback"""
        configs = []
        
        try:
            configFile = open(configPath, 'r')
            try:
                content = configFile.read()
                
                config = {
                    'config_type': 'generic',
                    'source_file': sourceFile.getName(),
                    'content_preview': content[:200]  # First 200 chars
                }
                configs.append(config)
            finally:
                configFile.close()
                
        except Exception as e:
            self.logger.log(Level.WARNING, "[{}] Generic config parse error: {}".format(MODULE_NAME, str(e)))
            
        return configs
        
    def _extractLocalPrefsData(self, jsonContent, sourceFileName):
        """Extract account and machine data from LocalPrefs.json"""
        try:
            config = {}
            config['config_type'] = 'LocalPrefs'
            config['source_file'] = sourceFileName
            
            # Extract account email
            emailPatterns = [
                r'"account_email"[:\s]*"([^"]+@[^"]+)"',
                r'"email"[:\s]*"([^"]+@[^"]+)"',
                r'"user"[:\s]*"([^"]+@[^"]+)"',
                r'"account"[:\s]*"([^"]+@[^"]+)"'
            ]
            
            for pattern in emailPatterns:
                match = re.search(pattern, jsonContent, re.IGNORECASE)
                if match:
                    config['account_email'] = match.group(1)
                    break
            
            # Extract machine ID
            machinePatterns = [
                r'"machine_id"[:\s]*"([^"]+)"',
                r'"machineId"[:\s]*"([^"]+)"',
                r'"device_id"[:\s]*"([^"]+)"',
                r'"client_id"[:\s]*"([^"]+)"'
            ]
            
            for pattern in machinePatterns:
                match = re.search(pattern, jsonContent, re.IGNORECASE)
                if match:
                    config['machine_id'] = match.group(1)
                    break
            
            # Extract profile ID
            profilePatterns = [
                r'"profile_id"[:\s]*"([^"]+)"',
                r'"profileId"[:\s]*"([^"]+)"',
                r'"user_profile"[:\s]*"([^"]+)"'
            ]
            
            for pattern in profilePatterns:
                match = re.search(pattern, jsonContent, re.IGNORECASE)
                if match:
                    config['profile_id'] = match.group(1)
                    break
            
            # Set defaults
            config.setdefault('account_email', '')
            config.setdefault('machine_id', '')
            config.setdefault('profile_id', '')
            
            return config
                
        except Exception as e:
            return None
            
    def _extractStartupTraceData(self, jsonContent, sourceFileName):
        """Extract startup timing and flags from startup_trace.json"""
        try:
            config = {}
            config['config_type'] = 'StartupTrace'
            config['source_file'] = sourceFileName
            
            # Extract startup time
            timePatterns = [
                r'"startup_time"[:\s]*"([^"]+)"',
                r'"start_time"[:\s]*"([^"]+)"',
                r'"timestamp"[:\s]*"([^"]+)"',
                r'"launch_time"[:\s]*"([^"]+)"'
            ]
            
            for pattern in timePatterns:
                match = re.search(pattern, jsonContent, re.IGNORECASE)
                if match:
                    config['startup_time'] = match.group(1)
                    break
            
            # Extract feature flags
            flagPatterns = [
                r'"flags"[:\s]*\[([^\]]+)\]',
                r'"features"[:\s]*\[([^\]]+)\]',
                r'"enabled"[:\s]*\[([^\]]+)\]'
            ]
            
            for pattern in flagPatterns:
                match = re.search(pattern, jsonContent, re.IGNORECASE)
                if match:
                    config['flags'] = match.group(1)
                    break
            
            # Extract error/crash codes
            errorPatterns = [
                r'"error_codes"[:\s]*\[([^\]]+)\]',
                r'"errors"[:\s]*\[([^\]]+)\]',
                r'"crash_info"[:\s]*"([^"]+)"',
                r'"exit_code"[:\s]*"([^"]+)"'
            ]
            
            for pattern in errorPatterns:
                match = re.search(pattern, jsonContent, re.IGNORECASE)
                if match:
                    config['error_codes'] = match.group(1)
                    break
            
            # Set defaults
            config.setdefault('startup_time', '')
            config.setdefault('flags', '')
            config.setdefault('error_codes', '')
            
            return config
                
        except Exception as e:
            return None
            
    def _extractParentMappingData(self, line, sourceFileName):
        """Extract parent-child mapping from parent mapping text line"""
        try:
            config = {}
            config['config_type'] = 'ParentMapping'
            config['source_file'] = sourceFileName
            
            # Try different formats for parent mapping
            # Format 1: child_id:parent_id
            colonMatch = re.search(r'([^:\s]+)[:\s]+([^:\s]+)', line)
            if colonMatch:
                config['child_id'] = colonMatch.group(1).strip()
                config['parent_id'] = colonMatch.group(2).strip()
                return config
            
            # Format 2: child_id parent_id (space separated)
            spaceMatch = re.search(r'([^\s]+)\s+([^\s]+)', line)
            if spaceMatch:
                config['child_id'] = spaceMatch.group(1).strip()
                config['parent_id'] = spaceMatch.group(2).strip()
                return config
            
            # Format 3: comma separated
            commaMatch = re.search(r'([^,]+),([^,]+)', line)
            if commaMatch:
                config['child_id'] = commaMatch.group(1).strip()
                config['parent_id'] = commaMatch.group(2).strip()
                return config
            
            # Set defaults if no pattern matches
            config['child_id'] = ''
            config['parent_id'] = ''
            config['raw_line'] = line[:100]  # Store raw line for debugging
            
            return config
                
        except Exception as e:
            return None
    
    # EXISTING METHODS (preserved functionality - truncated for brevity)
    def _parseStructuredLogGlobal(self, logPath, sourceFile):
        """EXISTING: Parse structured_log_global (preserved)"""
        # [Previous implementation preserved - Jython compatible file reading]
        events = []
        try:
            logFile = open(logPath, 'r')
            # ... existing implementation ...
            logFile.close()
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Structured log parse error: {}".format(MODULE_NAME, str(e)))
        return events
    
    def _parseDriveFSText(self, logPath, sourceFile):
        """EXISTING: Parse drive_fs.txt (preserved)"""
        # [Previous implementation preserved - Jython compatible file reading]
        events = []
        try:
            logFile = open(logPath, 'r')
            # ... existing implementation ...
            logFile.close()
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] drive_fs.txt parse error: {}".format(MODULE_NAME, str(e)))
        return events
    
    def _parseStartupTraceJSON(self, logPath, sourceFile):
        """EXISTING: Parse startup_trace.json (preserved)"""
        # [Previous implementation preserved - Jython compatible file reading]
        events = []
        try:
            jsonFile = open(logPath, 'r')
            # ... existing implementation ...
            jsonFile.close()
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] startup_trace.json parse error: {}".format(MODULE_NAME, str(e)))
        return events
    
    def _parseGenericLog(self, logPath, sourceFile):
        """EXISTING: Generic log parsing (preserved)"""
        # [Previous implementation preserved]
        events = []
        try:
            logFile = open(logPath, 'r')
            # ... existing implementation ...
            logFile.close()
        except Exception as e:
            self.logger.log(Level.WARNING, "[{}] Generic log parse error: {}".format(MODULE_NAME, str(e)))
        return events
        
    def _createDatabaseArtifacts(self, sourceFile, items):
        """EXISTING: Create database artifacts (preserved)"""
        count = 0
        
        try:
            skCase = Case.getCurrentCase().getSleuthkitCase()
            
            for item in items:
                if self.context.isJobCancelled():
                    break
                    
                artifact = sourceFile.newArtifact(self.dbArtType.getTypeID())
                attributes = ArrayList()
                
                if item.get('stable_id'):
                    attributes.add(BlackboardAttribute(self.attDrivefsId, MODULE_NAME, str(item['stable_id'])))
                
                if item.get('local_title'):
                    attributes.add(BlackboardAttribute(self.attFilename, MODULE_NAME, str(item['local_title'])))
                
                if item.get('mime_type'):
                    attributes.add(BlackboardAttribute(self.attMimeType, MODULE_NAME, str(item['mime_type'])))
                
                if item.get('file_size') and item['file_size'] > 0:
                    attributes.add(BlackboardAttribute(self.attFileSize, MODULE_NAME, long(item['file_size'])))
                
                if item.get('modified_date') and item['modified_date'] > 0:
                    modified = self._convertTimestamp(item['modified_date'])
                    attributes.add(BlackboardAttribute(self.attModifiedTime, MODULE_NAME, long(modified)))
                
                sync_status = "Deleted" if item.get('trashed') else "Synced"
                attributes.add(BlackboardAttribute(self.attSyncStatus, MODULE_NAME, sync_status))
                
                artifact.addAttributes(attributes)
                skCase.getBlackboard().postArtifact(artifact, MODULE_NAME)
                count += 1
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Database artifact creation error: {}".format(MODULE_NAME, str(e)))
            
        return count
        
    def _createLogArtifacts(self, sourceFile, events):
        """EXISTING: Create log artifacts (preserved)"""
        count = 0
        
        try:
            skCase = Case.getCurrentCase().getSleuthkitCase()
            
            for event in events:
                if self.context.isJobCancelled():
                    break
                    
                artifact = sourceFile.newArtifact(self.logArtType.getTypeID())
                attributes = ArrayList()
                
                if event.get('timestamp'):
                    try:
                        timestamp = self._parseEventTimestamp(event['timestamp'])
                        attributes.add(BlackboardAttribute(self.attLogEventTime, MODULE_NAME, long(timestamp)))
                    except:
                        pass
                
                if event.get('event_type'):
                    attributes.add(BlackboardAttribute(self.attLogEventType, MODULE_NAME, str(event['event_type'])))
                
                if event.get('file_id'):
                    attributes.add(BlackboardAttribute(self.attLogFileId, MODULE_NAME, str(event['file_id'])))
                
                if event.get('filename'):
                    attributes.add(BlackboardAttribute(self.attLogFilename, MODULE_NAME, str(event['filename'])))
                
                if event.get('user_email'):
                    attributes.add(BlackboardAttribute(self.attLogUserEmail, MODULE_NAME, str(event['user_email'])))
                
                if event.get('source_file'):
                    attributes.add(BlackboardAttribute(self.attLogSourceFile, MODULE_NAME, str(event['source_file'])))
                
                if event.get('message'):
                    message = str(event['message'])[:500]
                    attributes.add(BlackboardAttribute(self.attLogMessage, MODULE_NAME, message))
                
                artifact.addAttributes(attributes)
                skCase.getBlackboard().postArtifact(artifact, MODULE_NAME)
                count += 1
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Log artifact creation error: {}".format(MODULE_NAME, str(e)))
            
        return count
        
    def _createConfigArtifacts(self, sourceFile, configs):
        """NEW: Create config artifacts for forensic configuration analysis"""
        count = 0
        
        try:
            skCase = Case.getCurrentCase().getSleuthkitCase()
            
            for config in configs:
                if self.context.isJobCancelled():
                    break
                    
                artifact = sourceFile.newArtifact(self.configArtType.getTypeID())
                attributes = ArrayList()
                
                # Add config type
                if config.get('config_type'):
                    attributes.add(BlackboardAttribute(self.attConfigType, MODULE_NAME, str(config['config_type'])))
                
                # Add source file for traceability
                if config.get('source_file'):
                    attributes.add(BlackboardAttribute(self.attConfigSourceFile, MODULE_NAME, str(config['source_file'])))
                
                # LocalPrefs.json specific attributes
                if config.get('account_email'):
                    attributes.add(BlackboardAttribute(self.attAccountEmail, MODULE_NAME, str(config['account_email'])))
                
                if config.get('machine_id'):
                    attributes.add(BlackboardAttribute(self.attMachineId, MODULE_NAME, str(config['machine_id'])))
                
                if config.get('profile_id'):
                    attributes.add(BlackboardAttribute(self.attProfileId, MODULE_NAME, str(config['profile_id'])))
                
                # Startup trace specific attributes
                if config.get('startup_time'):
                    try:
                        timestamp = self._parseEventTimestamp(config['startup_time'])
                        attributes.add(BlackboardAttribute(self.attStartupTime, MODULE_NAME, long(timestamp)))
                    except:
                        pass
                
                if config.get('flags'):
                    attributes.add(BlackboardAttribute(self.attFeatureFlags, MODULE_NAME, str(config['flags'])))
                
                if config.get('error_codes'):
                    attributes.add(BlackboardAttribute(self.attErrorCodes, MODULE_NAME, str(config['error_codes'])))
                
                # Parent mapping specific attributes
                if config.get('parent_id'):
                    attributes.add(BlackboardAttribute(self.attParentId, MODULE_NAME, str(config['parent_id'])))
                
                if config.get('child_id'):
                    attributes.add(BlackboardAttribute(self.attChildId, MODULE_NAME, str(config['child_id'])))
                
                artifact.addAttributes(attributes)
                skCase.getBlackboard().postArtifact(artifact, MODULE_NAME)
                count += 1
                
        except Exception as e:
            self.logger.log(Level.SEVERE, "[{}] Config artifact creation error: {}".format(MODULE_NAME, str(e)))
            
        return count
        
    def _convertTimestamp(self, timestamp):
        """EXISTING: Convert timestamps (preserved)"""
        if timestamp > 10**12:  # Microseconds
            return timestamp / 1000000
        elif timestamp > 10**9:  # Milliseconds
            return timestamp / 1000
        return timestamp
        
    def _parseEventTimestamp(self, timeString):
        """EXISTING: Parse event timestamps (preserved)"""
        try:
            match = re.search(r'(\d{10,13})', timeString)
            if match:
                timestamp = long(match.group(1))
                return self._convertTimestamp(timestamp)
                
            dateMatch = re.search(r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})', timeString)
            if dateMatch:
                import time
                return long(time.time())
            
            import time
            return long(time.time())
            
        except:
            import time
            return long(time.time())

# Required for Autopsy
def getFactory():
    return GoogleDriveIngestModuleFactory()
